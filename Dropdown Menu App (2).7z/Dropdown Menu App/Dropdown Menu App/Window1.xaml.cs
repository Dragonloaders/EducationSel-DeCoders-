﻿using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
namespace Dropdown_Menu_App
{

    public partial class Window1 : Window
    {
        static public string connectionString = "Data Source=TRE1D52\\SQLEXPRESS;Initial Catalog=EducationOrganisation;Integrated Security=True";
        static public int userID;
        public Window1()
        {
            InitializeComponent();
        }

        private void textEmail_MouseDown(object sender, MouseButtonEventArgs e)
        {
            txtEmail.Focus();
        }

        private void txtEmail_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtEmail.Text) && txtEmail.Text.Length > 0)
            {
                textEmail.Visibility = Visibility.Collapsed;
            }
            else
            {
                textEmail.Visibility = Visibility.Visible;
            }
        }
        private void textPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)

        {
            if (!string.IsNullOrEmpty(txtPassword.Password) && txtPassword.Password.Length > 0)
            {
                textPassword.Visibility = Visibility.Collapsed;
            }
            else
            {
                textPassword.Visibility = Visibility.Visible;
            }
        }

        private void textPassword_MouseDown(object sender, MouseButtonEventArgs e)
        {
            txtPassword.Focus();
        }

        private void login_button(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtEmail.Text) && !string.IsNullOrEmpty(txtPassword.Password)) 
            {

                string login = txtEmail.Text.Trim();
                string password = txtPassword.Password.Trim();
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    // Создание команды для вызова хранимой процедуры
                    SqlCommand command = new SqlCommand("AuthenticateUser", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    // Параметры хранимой процедуры
                    command.Parameters.AddWithValue("@login", login);
                    command.Parameters.AddWithValue("@password", password);
                    // Выполнение команды
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        // Пользователь найден, получение данных пользователя
                        reader.Read();
                        int userRole = reader.GetInt32(3);
                        userID = reader.GetInt32(0);
                        if (userRole == 1)
                        {
                            ApplicationWindowForARegularUser newWindow = new ApplicationWindowForARegularUser();
                            newWindow.Show();
                        }
                        if (userRole == 2)
                        {
                            AdministratorControlWindow newWindow = new AdministratorControlWindow();
                            newWindow.Show();
                        }
                        if (userRole == 3)
                        {
                            AccountingAndMarkingOfEquipment newWindow = new AccountingAndMarkingOfEquipment();
                            newWindow.Show();
                        }
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Пользователь не найден.");
                    }
                }
                MessageBox.Show("Успешный вход");
                MainWindow objmainWindow = new MainWindow();
                this.Visibility = Visibility.Hidden;
                objmainWindow.Show();
            }
            else
            {
                MessageBox.Show("Ошибка ввода логина или пароля");
            }
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) 
            {
                this.DragMove();
            }
        }

        private void Image_MouseUp(object sender, MouseButtonEventArgs e)
        {
            Application.Current.Shutdown();
        }



        private void regist_button(object sender, RoutedEventArgs e)
        {

            Window2 objmainWindow = new Window2();
            this.Visibility = Visibility.Hidden;
            objmainWindow.Show();
        }

        private void txtPassword_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
